#ifndef __EF_ADF4351_H__
#define __EF_ADF4351_H__

#include <Arduino.h>
#include <avr/pgmspace.h>


class EF_ADF4351{
	public:
		 EF_ADF4351(int D_CLK, int D_DATA, int D_LE);
     void init(void);
    
     void WriteRegister(long ww);
    

   private:
     int DATA,CLK,LE;
	
};

#endif
