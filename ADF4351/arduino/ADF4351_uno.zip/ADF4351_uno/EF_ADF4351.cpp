#include "EF_ADF4351.h"


EF_ADF4351::EF_ADF4351(int D_CLK, int D_DATA, int D_LE)
	{
		pinMode(D_CLK, OUTPUT);
   	pinMode(D_DATA, OUTPUT);
   	pinMode(D_LE, OUTPUT);
   	
   	
   	CLK = D_CLK;
   	DATA=D_DATA;
   	LE=D_LE;
	}


void EF_ADF4351::init(void)
	{
		digitalWrite(CLK, 0);
   	digitalWrite(DATA, 0);
   	digitalWrite(LE, 0);
	}


	
void EF_ADF4351::WriteRegister(long ww)
	{
		
	  long  y;
	  int i;
	  digitalWrite(LE, 0);
	  y=ww;
	  
	 
	  for(i=0; i<32; i++)
	  {
		  
		  if(((y<<i)&0x80000000)==0x80000000)
		  {
			  digitalWrite(DATA,1);
			  
		  }
		  else
		  {
			 digitalWrite(DATA,0) ;
			 
		  }
	    
	    digitalWrite(CLK, 1);
	    digitalWrite(CLK, 0);
	  }
	   digitalWrite(LE, 1);
	   delay(1);
	   digitalWrite(LE, 0);
	}	


	













